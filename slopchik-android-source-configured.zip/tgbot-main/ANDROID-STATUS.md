# Слопчик для Android — состояние работ

Добавлена папка `android-app` с исходным Android-проектом (Kotlin + WebView), обновлён web-интерфейс на светлую тему и добавлен Telegram deep-link handshake для входа в самостоятельный APK. `bot.py` обрабатывает одноразовую ссылку `/start appauth_…`; `app_api.py` выдаёт серверную сессию после подтверждения Telegram-аккаунта.

Для запуска нужно задать `BOT_USERNAME` в окружении backend и `ALLOWED_USERS` с Telegram ID пользователей, которым разрешён вход. Адрес приложения Render уже прописан в Android-проекте: `https://tgbot-naew.onrender.com/app/`. После публикации исходников в GitHub можно запустить workflow **Build Android APK** и получить APK как Actions artifact.

Пока не выполнялась полноценная сборка APK: в рабочем окружении нет Android SDK/Gradle. Android-проект передан как исходники для сборки в Android Studio.
